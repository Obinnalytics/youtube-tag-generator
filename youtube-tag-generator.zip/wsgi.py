from youtube_tag_generator import app

if __name__ == "__main__":
    app.run() 